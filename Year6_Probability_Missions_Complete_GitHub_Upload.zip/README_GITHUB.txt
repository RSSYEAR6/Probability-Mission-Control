YEAR 6 PROBABILITY MISSIONS — GITHUB PAGES

1. Extract the ZIP.
2. Upload index.html and all six Mission_*.html files into the ROOT of the same GitHub repository.
3. In GitHub repository Settings > Pages, choose Deploy from a branch, select main and /(root), and Save.
4. Open the GitHub Pages address shown in Settings > Pages.

IMPORTANT: The ZIP itself is not the website. Upload the files inside it. Keep filenames unchanged because index.html links to these exact names.

Review points: Provide an additional card-based chance simulation transfer activity, explicit frequency versus relative-frequency recording, and opportunities to compare multiple simulation tables. External NCTM Adjustable Spinner requires internet access and may be blocked by school filtering; Mission 5 also includes its own simulator.

This package does not include or reproduce the assessment questions.
